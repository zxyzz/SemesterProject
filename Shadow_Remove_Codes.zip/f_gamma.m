%Author: Dominic R�fenacht, May 2012
%Purpose: Computes a sigmoid function with slope a, and centered at b.

function out = f_gamma(in, a, b)
out = 1.0 ./ (1.0 + exp(-a .*(in.^(1/gamma)-b)));