function ratio = compute_ratio(Temp, lambda1, lambda2)

lambda1 = lambda1 *10^-9;
lambda2 = lambda2 *10^-9;
c2 = 1.43e-2;

if(strcmp(Temp, 'day'))
    T = 6500;
elseif (strcmp(Temp, 'sun'))
    T = 5500;
else
    error('Either day or sun is allowed...')
end

ratio = (lambda1/lambda2).^(-5) * (exp(c2/(T*lambda2)) -1)/ (exp(c2/(T*lambda1)) -1);