function [Value T kappa eta] = jisuan1 (z, x, y)
%p=min(z(:));
%q=max(z(:));
for T=1:255
    S = z < T;
    b1 = mean2(z(S==1));
    bb1(T) = b1;
    b2 = mean2(z(S==0));
    bb2(T) = b2;
end

k = 1:255;
w = k.*(2*mean2(z)-k);
[m n] = max(w.*((bb2-bb1)));
T = n;
Value = m;
S = z < T;
a1 = mean2(x(S==1));
a2 = mean2(x(S==0));
a3 = mean2(x);
kappa = (a2-a1)/a3;
c1 = mean2(y(S==1));
c2 = mean2(y(S==0));
c3 = mean2(y);
eta = (c2-c1)/c3;
