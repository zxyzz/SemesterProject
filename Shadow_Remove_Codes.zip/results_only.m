%Author: Dominic R�fenacht, January 2013

%Purpose: Compute statistics and generate HTML file for previously computed shadow masks. The
%result is the same as for process_all.m, but the shadow masks are not
%computed here.

clear all
results_folder = 'Results Evaluation';
gt_folder = 'Ground_Truth';
eval_dir = 'Results Evaluation';
set = 'Outdoor';

if(strcmp(set, ''))
    images_folder = [eval_dir '/Linim/'];
else
    images_folder = [eval_dir '/Linim/' set '/'];
end

methods = {'Ours', 'Tian', 'Guo'};

for j=1:length(methods)
    if(~exist([results_folder '/' methods{j}], 'dir'))
        disp(['Creating directory ' [results_folder '/' methods{j}] ' to save shadow maps...']);
        mkdir([results_folder '/' methods{j}]);
    end
end

if(~exist([results_folder '/Images/Thumbnails'], 'dir'))
        disp(['Creating directory ' [results_folder '/Images/Thumbnails'] ' to save thumbnails...']);
        mkdir([results_folder '/Images/Thumbnails']);
end

if(~exist([results_folder '/Ground_Truth/Thumbnails'], 'dir'))
        disp(['Creating directory ' [results_folder '/Ground_Truth/Thumbnails'] ' to save thumbnails...']);
        mkdir([results_folder '/Ground_Truth/Thumbnails']);
end

%Get all the images that are in "images_folder"
filenames_vis = dir(fullfile(['./' images_folder '*_vis.png']));
filenames_nir = dir(fullfile(['./' images_folder '*_nir.png']));

if(length(filenames_vis) ~= length(filenames_nir))
    %error(['The number of visible and NIR images in the folder ' fullfile(['./' images_folder]) ' is not the same!']);
end


%HTML
web = 0;
horizontal_screen_resolution = 1400;
if(web == 1)
    horizontal_screen_resolution = 1600;
end

iSize = num2str(floor((horizontal_screen_resolution-((2+length(methods))*25))/(3+length(methods))));%num2str(300); %Width of one image in the HTML file for comparison (generated at the end of this code)

disp('Computing statistics and creating HTML file...')
htmlStr = [];

htmlStr = sprintf('%s <div style="font-family:Lucida Grande,Helvetica,Arial,sans-serif;font-size: 12px;" align="center" >\n<table BORDER=2 CELLPADDING=5 RULES=GROUPS FRAME=BOX>\n<THEAD>\n<tr align="center">\n<th>Original Image </th> <th>NIR Image </th> <th> Ground Truth </th> ', htmlStr);

%Create column titles for each method
for j=1:length(methods)
    htmlStr = sprintf('%s <th> %s </th> ', htmlStr, methods{j});
end
%End the header line
htmlStr = sprintf('%s </tr>\n</THEAD>\n', htmlStr);

for i=1:length(filenames_vis)
    foo = textscan(filenames_vis(i).name,'%s', 'delimiter', '.');
    namebase = foo{1}{1};
    foo = textscan(namebase,'%s', 'delimiter', '_');
    number = foo{1}{2};
    namebase = filenames_vis(i).name(1:(regexp(filenames_vis(i).name, '_vis') - 1));
    %Load the groundtruth as well as shadow masks in "directory"
    try
        if(strcmp(namebase(end), 'f') || strcmp(namebase(end), 'i'))
            number = number(1:end-1);
        end
        
        gt = rgb2gray(im2double(imread([eval_dir '/' gt_folder '/img_' number '_gt.png'])));
    catch
        movefile([eval_dir '/' gt_folder '/img_' number '.png'], [eval_dir '/' gt_folder '/img_' number '_gt.png']);
        gt = rgb2gray(im2double(imread([eval_dir '/' gt_folder '/img_' number '_gt.png'])));
        
    end
    %Make sure the ground truth is binary
    gt(gt >= 0.5) = 1.0;
    gt(gt < 0.5) = 0.0;
    [m,n] = size(gt);
    

    if(web == 1)
        original_filename_vis = ['http://ivrg.epfl.ch/files/content/sites/ivrg/files/research/druefena/nir_shadows/Images/' filenames_vis(i).name];
        original_filename_nir = ['http://ivrg.epfl.ch/files/content/sites/ivrg/files/research/druefena/nir_shadows/Images/' filenames_nir(i).name];
        gt_filename = ['http://ivrg.epfl.ch/files/content/sites/ivrg/files/research/druefena/nir_shadows/Ground_Truth/img_' number '_gt.png'];
        
        %Thumbnails
        original_filename_vis_thumb = ['http://ivrg.epfl.ch/files/content/sites/ivrg/files/research/druefena/nir_shadows/Images/Thumbnails/' filenames_vis(i).name];
        original_filename_nir_thumb = ['http://ivrg.epfl.ch/files/content/sites/ivrg/files/research/druefena/nir_shadows/Images/Thumbnails/' filenames_nir(i).name];
        gt_filename_thumb = ['http://ivrg.epfl.ch/files/content/sites/ivrg/files/research/druefena/nir_shadows/Ground_Truth/Thumbnails/img_' number '_gt.png'];
    else
        original_filename_vis = ['./Images/' filenames_vis(i).name];
        original_filename_nir = ['./Images/' filenames_nir(i).name];
        gt_filename = ['./Ground_Truth/img_' number '_gt.png'];
        
        %Thumbnails
        original_filename_vis_thumb = ['./Images/Thumbnails/' filenames_vis(i).name];
        original_filename_nir_thumb = ['./Images/Thumbnails/' filenames_nir(i).name];
        gt_filename_thumb = ['./Ground_Truth/Thumbnails/img_' number '_gt.png'];        
    end
    
    %Check if thumbnail already exists
    %if(~exist([eval_dir '/Images/Thumbnails/' filenames_vis(i).name], 'file'))
        %If not, create it
        toto = im2double(imread([eval_dir '/Images/' filenames_vis(i).name]));
        imwrite(imresize(toto, [NaN str2num(iSize)]), [eval_dir '/Images/Thumbnails/' filenames_vis(i).name]);
    %end
    
    %if(~exist([eval_dir '/Images/Thumbnails/' filenames_nir(i).name], 'file'))
        %If not, create it
        toto = im2double(imread([eval_dir '/Images/' filenames_nir(i).name]));
        imwrite(imresize(toto, [NaN str2num(iSize)]), [eval_dir '/Images/Thumbnails/' filenames_nir(i).name]);
    %end
    
    %if(~exist([eval_dir '/Ground_Truth/Thumbnails/img_' number '_gt.png'], 'file'))
        %If not, create it
        toto = im2double(imread([eval_dir  '/Ground_Truth/img_' number '_gt.png']));
        toto = imresize(toto, [NaN str2num(iSize)]);
        toto(toto > 0.5) = 1.0;
        toto(toto <= 0.5) = 0.0;
        imwrite(toto, [eval_dir '/Ground_Truth/Thumbnails/img_' number '_gt.png']);
    %end
    
    htmlStr = sprintf('%s\n<TBODY>\n<tr align="center"> <td><a href="%s"><img src="%s" width=%s></a></td>  <td><a href="%s"><img src="%s" width=%s></a></td>  <td><a href="%s"><img src="%s" width=%s></a></td>', htmlStr, original_filename_vis, original_filename_vis_thumb, iSize, original_filename_nir, original_filename_nir_thumb, iSize, gt_filename, gt_filename_thumb, iSize);
    
    for j=1:length(methods)
        %Load mask and resize it to have the same size as the ground truth map
        %keyboard
        mask = im2double(imread([results_folder '/' methods{j} '/' namebase '_' lower(methods{j}) '.png']));
        [m1 n1] = size(mask);
        [m2 n2] = size(gt);
        if(m1 ~= m2 || n1 ~=n2)
           mask = imresize(mask, [m2, n2]); 
        end
        %Make sure the mask is binary
        mask(mask >= 0.5) = 1.0;
        mask(mask < 0.5) = 0.0;

        [tp fp tn fn res(i,j)] = compute_accuracy(mask, gt);
        mcc(i,j) = compute_mcc(tp, fp, tn, fn);
        
        %Save results
        if(~exist([eval_dir '/' methods{j} '/Thumbnails/'], 'dir'))
            disp('Creating directory to save results...');
            mkdir([eval_dir '/' methods{j} '/Thumbnails/']);
        end
        
        
        if(web == 1)
            mask_filename{j} = ['http://ivrg.epfl.ch/files/content/sites/ivrg/files/research/druefena/nir_shadows/' methods{j} '/' namebase '_' lower(methods{j}) '.png'];
            mask_filename_thumb{j} = ['http://ivrg.epfl.ch/files/content/sites/ivrg/files/research/druefena/nir_shadows/' methods{j} '/Thumbnails/' namebase '_' lower(methods{j}) '.png'];
        else
            mask_filename{j} = ['./' methods{j} '/' namebase '_' lower(methods{j}) '.png'];
            mask_filename_thumb{j} = ['./' methods{j} '/Thumbnails/' namebase '_' lower(methods{j}) '.png'];
        end
        
        %Save thumbnail of mask
        toto = imresize(mask, [NaN str2num(iSize)]);
        toto(toto > 0.5) = 1.0;
        toto(toto <= 0.5) = 0.0;
        imwrite(toto, [eval_dir '/' methods{j} '/Thumbnails/' namebase '_' lower(methods{j}) '.png']);
        
        htmlStr = sprintf('%s <td><a href="%s"><img src="%s" width=%s></a></td>', htmlStr, mask_filename{j}, mask_filename_thumb{j}, iSize);
    end
    
    htmlStr = sprintf('%s </tr> \n', htmlStr);
    htmlStr = sprintf('%s <tr align="center"> <td> %s </td> <td> %s </td> <td> Ground Truth </td> ', htmlStr, filenames_vis(i).name, filenames_nir(i).name);
    
    for j=1:length(methods)
        htmlStr = sprintf('%s <td> Acc= %s, MCC= %s </td>', htmlStr, num2str(res(i,j)), num2str(mcc(i,j)));
    end
    htmlStr = sprintf('%s </tr>\n</TBODY> \n', htmlStr);
end

htmlStr = sprintf('%s\n<TFOOT>\n<tr> <td> %s images in total. </td> <td>  </td> <td>  </td> ', htmlStr, num2str(length(filenames_vis)));
%Compute some statistics
for j=1:length(methods)
    avg(j) = mean(res(:,j));
    stdev(j) = std(res(:,j));
    mcc_mean(j) = mean(mcc(:,j));
    mcc_stddev(j) = std(mcc(:,j));
    htmlStr = sprintf('%s <td>  Average: %s <br> Std dev.: %s <br> Mean MCC : %s <br> Std dev MCC: %s </td>', htmlStr, num2str(avg(j)), num2str(stdev(j)), num2str(mcc_mean(j)), num2str(mcc_stddev(j)));

end
clear res;
htmlStr = sprintf('%s </tr>\n</TFOOT>\n', htmlStr);

htmlStr = sprintf('%s\n</table>\n</div> \n', htmlStr);

htmlStr = sprintf('<!DOCTYPE HTML>\n\n<html>\n<head>\n</head>\n\n<body>\n%s\n</body>\n</html>', htmlStr);

htmlFilename = [eval_dir '/results_' lower(set) '.html'];

fid = fopen(htmlFilename, 'w');
fprintf(fid, '%s', htmlStr);
fclose(fid);

disp('All done...')