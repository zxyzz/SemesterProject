% Implementation (with some adaptations) of the technical report:
% C. Fredembach and S.S�sstrunk, "Automatic and accurate shadow detection using (potentially) a single
% image using near-infrared information", EPFL Tech Report 165527, 2010.
% Author: Dominic R�fenacht
% Last Revision: 18.07.2012

function varargout = shadow_detection_gui(varargin)
% SHADOW_DETECTION_GUI MATLAB code for shadow_detection_gui.fig
%      SHADOW_DETECTION_GUI, by itself, creates a new SHADOW_DETECTION_GUI or raises the existing
%      singleton*.
%
%      H = SHADOW_DETECTION_GUI returns the handle to a new SHADOW_DETECTION_GUI or the handle to
%      the existing singleton*.
%
%      SHADOW_DETECTION_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SHADOW_DETECTION_GUI.M with the given input arguments.
%
%      SHADOW_DETECTION_GUI('Property','Value',...) creates a new SHADOW_DETECTION_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before shadow_detection_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to shadow_detection_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help shadow_detection_gui

% Last Modified by GUIDE v2.5 13-Sep-2012 14:09:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @shadow_detection_gui_OpeningFcn, ...
    'gui_OutputFcn',  @shadow_detection_gui_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before shadow_detection_gui is made visible.
function shadow_detection_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% Choose default command line output for shadow_detection_gui
handles.output = hObject;

handles.thresh = 10.0;
handles.theta = 0.1;

set(handles.edit_threshold, 'String', 10.0);
        

set(handles.slider1, 'Value', handles.theta);
set(handles.edit_theta, 'String', handles.theta);

handles.a = 14.0;
handles.b = 0.5;
set(handles.edit_b, 'String', 0.5);
xx = 0:0.01:1;
yy = 1.0 ./ (1 + exp(-handles.a .*(1 - xx.^(1/2.2)-handles.b)));
axes(handles.axes_sigmoid)
plot(xx, yy)
figure(1)
plot(xx, yy, 'LineWidth', 2)
xlabel('Normalized input value')
ylabel('Normalized output value')
axis([0.0, 1.0, 0.0, 1.0]);

set(handles.uipanel_histogram, 'Visible', 'off');
set(handles.uipanel_map, 'Visible', 'off');
set(handles.pushbutton_computeMap, 'Visible', 'off');

set(handles.radiobutton_shadowmapOnly, 'Value', 1);
set(handles.radiobutton_visshadow, 'Value', 0);
handles.visualization = 'Shadow';

set(handles.checkbox_useratios, 'Value', 1);
handles.useratios = 1;

set(handles.checkbox_smooth_result, 'Value', 0);
handles.smooth_result = 0;

set(handles.checkbox_handle_sky, 'Value', 1);
handles.handle_sky = 1;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = shadow_detection_gui_OutputFcn(hObject, eventdata, handles)
% Get default command line output from handles structure
varargout{1} = handles.output;

%%%% MAIN BUTTON CALLBACKS
% --- Executes on button press in pushbutton_load.
function pushbutton_load_Callback(hObject, eventdata, handles)
set(handles.uipanel_histogram, 'Visible', 'off');
set(handles.uipanel_map, 'Visible', 'off');
set(handles.pushbutton_computeMap, 'Visible', 'off')

[handles.filename_vis, handles.pathname_vis] = uigetfile( ...
    {'*.PNG;*.png;*.TIFF;*.tiff;*.TIF;*.tif;*.JPEG;*.jpeg;*.JPG;*.jpg','Image file (*.PNG, *.TIFF, *.JPEG)'}, ...
    'Please select the visible image', 'MultiSelect', 'off');
[handles.filename_nir, handles.pathname_nir] = uigetfile( ...
    {'*.PNG;*.png;*.TIFF;*.tiff;*.TIF;*.tif;*.JPEG;*.jpeg;*.JPG;*.jpg','Image file (*.PNG, *.TIFF, *.JPEG)'}, ...
    'Please select the NIR image', 'MultiSelect', 'off');

%If only one image is selected, uigetfile returns "String" instead of
%cells. To unify the processing, we convert this string to a cell
handles.filename_vis = cellstr(handles.filename_vis);

%If only one image is selected, uigetfile returns "String" instead of
%cells. To unify the processing, we convert this string to a cell
handles.filename_nir = cellstr(handles.filename_nir);

handles.vis = im2double(imread([handles.pathname_vis handles.filename_vis{1}]));
try
    handles.nir = rgb2gray(im2double(imread([handles.pathname_nir handles.filename_nir{1}])));
catch
    handles.nir = im2double(imread([handles.pathname_nir handles.filename_nir{1}]));
end

m1=min(min(handles.vis)); M1=max(max(handles.vis));
m2=min(min(handles.nir)); M2=max(max(handles.nir));

handles.vis(:,:,1)=(handles.vis(:,:,1)-m1(:,:,1))/(M1(:,:,1)-m1(:,:,1));
handles.vis(:,:,2)=(handles.vis(:,:,2)-m1(:,:,2))/(M1(:,:,2)-m1(:,:,2));
handles.vis(:,:,3)=(handles.vis(:,:,3)-m1(:,:,3))/(M1(:,:,3)-m1(:,:,3));
handles.nir(:,:,1)=(handles.nir(:,:,1)-m2(:,:,1))/(M2(:,:,1)-m2(:,:,1));

%Resize
%handles.vis = imresize(handles.vis, [1408 NaN]);
%handles.nir = imresize(handles.nir, [1408 NaN]);

%make sure that everything is between 0 and 1.
handles.vis(handles.vis > 1.0) = 1.0;
handles.vis(handles.vis < 0.0) = 0.0;
handles.nir(handles.nir > 1.0) = 1.0;
handles.nir(handles.nir < 0.0) = 0.0;

set(handles.text_loadConfirmation, 'String', ['Image ' handles.filename_vis{1} ' loaded...']);
set(handles.pushbutton_computeMap, 'Visible', 'on')

% Update handles structure
guidata(hObject, handles);

% --- Executes on button press in pushbutton_computeMap.
function pushbutton_computeMap_Callback(hObject, eventdata, handles)
gamma = 2.2;
%gamma = 1.0;
eval_dir = 'Results Evaluation';
gt_folder = 'Ground_Truth';
%L = rgb2gray(handles.vis);
L = (handles.vis(:,:,1) + handles.vis(:,:,2) + handles.vis(:,:,3))/3.0;

L = L.^(1./gamma);

D_vis = f(L, handles.a, handles.b);%1 - L;
%D_vis = L;

nir = handles.nir;

if(handles.handle_sky == 1)
    %Hack to avoid sky being falsely detected as shadow
    nir(handles.vis(:,:,3) > 0.4 & handles.nir < 0.2) = 0.5;
end
%imwrite(L, 'nir.png');
%imwrite(D_nir, 'Dnir.png');
nir = nir.^(1/gamma);
D_nir = f(nir, handles.a, handles.b);
%D_nir = nir;



%D = f(D_vis, handles.a, handles.b) .* f(D_nir, handles.a, handles.b); %Center sigmoid at handles.b

D = D_vis.*D_nir;

[m,n,c] = size(handles.vis);

if(handles.useratios == 1)
    %vis = handles.vis.^(1/0.45);
    vis = handles.vis;
    Fk = zeros(m,n,c);
    %Fk(:,:,1) = handles.vis(:,:,1)./nir;
    %Fk(:,:,2) = handles.vis(:,:,2)./nir;
    %Fk(:,:,3) = handles.vis(:,:,3)./nir;
    
    Fk(:,:,1) = vis(:,:,1)./nir;
    Fk(:,:,2) = vis(:,:,2)./nir;
    Fk(:,:,3) = vis(:,:,3)./nir;
    
    
    
    F = min(max(Fk, [], 3), handles.thresh);
    
    F = F./handles.thresh;
    handles.M = (1-D).*(1-F);
    imwrite(F, 'F.png');
else
    handles.M = (1-D);
end

[a, b] = size(handles.M);
HIST_LENGTH = ceil(log2(a*b)+1); %Sturge's Rule

try
    [~, TT] = valley_hist(handles.M, floor(1.6*HIST_LENGTH)); %% !!!!!! CHANGED FROM HISTLENGTH !!!!!!
catch
    disp(['Image ' handles.filename_vis ': Valley could not be determined. Using value of 0.5']);
    TT = 0.5;
end

handles.theta = TT;
set(handles.slider1, 'Value', handles.theta);
set(handles.edit_theta, 'Value', handles.theta);
set(handles.edit_theta, 'String', num2str(handles.theta));

figure(1)
imhist(handles.M);

handles.M_bin = handles.M <= handles.theta;
%handles.M_bin = handles.M >= handles.theta; %CHANGED*********************************************

%Smooth result. Remove small shadow regions
if(handles.smooth_result == 1)
    [L,NUM] = bwlabel(handles.M_bin, 8);
    for i=1:NUM
        if sum(sum(L==i)) < 100;
            handles.M_bin(L==i) = 0;
        end
    end
end

filename = handles.filename_vis{1};
foo = textscan(filename,'%s', 'delimiter', '.');
namebase = foo{1}{1};
foo = textscan(namebase,'%s', 'delimiter', '_');
number = foo{1}{2};
namebase = filename(1:(regexp(filename, '_vis') - 1));
%Load the groundtruth as well as shadow masks in "directory"

if(strcmp(namebase(end), 'f') || strcmp(namebase(end), 'i'))
    number = number(1:end-1);
end

handles.gt = rgb2gray(im2double(imread([eval_dir '/' gt_folder '/img_' number '_gt.png'])));
[m,n] = size(handles.M_bin);
handles.gt = imresize(handles.gt, [m,n]);

%Make sure the ground truth is binary
handles.gt(handles.gt >= 0.5) = 1.0;
handles.gt(handles.gt < 0.5) = 0.0;



[tp fp tn fn res] = compute_accuracy(handles.M_bin, handles.gt);
disp(['Accuracy: ' num2str(res)])
set(handles.text_accuracy, 'String', ['Accuracy: ' num2str(res.*100) '%']);


visualize(handles)
axes(handles.axes_histogram);
% imhist(handles.M);
imhist(handles.M); %CHANGED*********************************************************
hold on
line([handles.theta handles.theta], [0 10e6], 'Color', 'r');
hold off


%Saving (for testing)
imwrite(D_vis, 'Dvis.png');
imwrite(D_nir, 'Dnir.png');
imwrite(D, 'D.png');

imwrite(handles.M, 'M.png');


set(handles.uipanel_histogram, 'Visible', 'on');
set(handles.uipanel_map, 'Visible', 'on');

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in pushbutton_save.
function pushbutton_save_Callback(hObject, eventdata, handles)
foo = handles.filename_vis{1};
filenameBase = foo(1:strfind(foo, '.')-1);
if(~exist('./Results', 'dir'))
    disp('Creating directory ./Results/ to save shadow maps...');
    mkdir('./Results');
end
imwrite(handles.M_bin, ['./Results/' filenameBase '_shadowmap_t' num2str(handles.theta) '.png'], 'png');

%Saving (for testing)
%imwrite(handles.M, 'M.png');
%imwrite(handles.M_bin, 'Mbin.png');

set(handles.text_saveConfirmation, 'String', ['Shadow map saved as ' filenameBase '_shadowmap_t' num2str(handles.theta) '.png']);

% Update handles structure
guidata(hObject, handles);


%%%% CALLBACKS FOR RADIO BUTTONS, SLIDERS ETC...
function edit_a_Callback(hObject, eventdata, handles)
handles.a = str2double(get(hObject,'String'));

xx = 0:0.01:1;
yy = 1.0 ./ (1 + exp(-handles.a .*(xx-handles.b)));
axes(handles.axes_sigmoid)
plot(xx, yy)
axis([0.0, 1.0, 0.0, 1.0]);

% Update handles structure
guidata(hObject, handles);


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
handles.theta = get(hObject, 'Value');

set(handles.edit_theta, 'Value', handles.theta);
set(handles.edit_theta, 'String', num2str(handles.theta));

handles.M_bin = handles.M <= handles.theta;

visualize(handles);

[tp fp tn fn res] = compute_accuracy(handles.M_bin, handles.gt);
disp(['Accuracy: ' num2str(res)])
set(handles.text_accuracy, 'String', ['Accuracy: ' num2str(res.*100) '%']);

axes(handles.axes_histogram);
imhist(handles.M);
hold on
line([handles.theta handles.theta], [0 10e6], 'Color', 'r');
hold off

% Update handles structure
guidata(hObject, handles);


function edit_threshold_Callback(hObject, eventdata, handles)
handles.thresh = str2double(get(hObject,'String'));

% Update handles structure
guidata(hObject, handles);

function edit_theta_Callback(hObject, eventdata, handles)
handles.theta = str2double(get(hObject,'String'));

set(handles.slider1, 'Value', handles.theta);

handles.M_bin = handles.M <= handles.theta;

visualize(handles);

axes(handles.axes_histogram);
imhist(handles.M);
hold on
line([handles.theta handles.theta], [0 10e6], 'Color', 'r');
hold off

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in radiobutton_shadowmapOnly.
function radiobutton_shadowmapOnly_Callback(hObject, eventdata, handles)
set(handles.radiobutton_shadowmapOnly, 'Value', 1);
set(handles.radiobutton_visshadow, 'Value', 0);

handles.visualization = 'Shadow';

visualize(handles)

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in radiobutton_visshadow.
function radiobutton_visshadow_Callback(hObject, eventdata, handles)
set(handles.radiobutton_shadowmapOnly, 'Value', 0);
set(handles.radiobutton_visshadow, 'Value', 1);

handles.visualization = 'VisShadow';

visualize(handles)

% Update handles structure
guidata(hObject, handles);


%%%% HELPER FUNCTIONS
%Function used to visualize the shadow maps (potentially along with
%corresponding visible image)
function visualize(handles)
[m,n,c] = size(handles.vis);
axes(handles.axes_image)
cla
axes(handles.axes_visPortrait)
cla
axes(handles.axes_shadowPortrait)
cla
axes(handles.axes_visLandscape)
cla
axes(handles.axes_shadowLandscape)
cla

switch handles.visualization
    case 'Shadow'
        set(handles.axes_image, 'Visible', 'on')
        set(handles.axes_visPortrait, 'Visible', 'off')
        set(handles.axes_shadowPortrait, 'Visible', 'off')
        set(handles.axes_visLandscape, 'Visible', 'off')
        set(handles.axes_shadowLandscape, 'Visible', 'off')
        axes(handles.axes_image)
    case 'VisShadow'
        if(m >= n)
            set(handles.axes_image, 'Visible', 'off')
            set(handles.axes_visPortrait, 'Visible', 'on')
            set(handles.axes_shadowPortrait, 'Visible', 'on')
            set(handles.axes_visLandscape, 'Visible', 'off')
            set(handles.axes_shadowLandscape, 'Visible', 'off')
            axes(handles.axes_visPortrait)
            imshow(handles.vis)
            axes(handles.axes_shadowPortrait)
        else
            set(handles.axes_image, 'Visible', 'off')
            set(handles.axes_visPortrait, 'Visible', 'off')
            set(handles.axes_shadowPortrait, 'Visible', 'off')
            set(handles.axes_visLandscape, 'Visible', 'on')
            set(handles.axes_shadowLandscape, 'Visible', 'on')
            axes(handles.axes_visLandscape)
            imshow(handles.vis)
            axes(handles.axes_shadowLandscape)
            
        end
end
imshow(handles.M_bin)

[object, fig] = gcbo;
guidata(object, handles);

%{
% Function that takes the map image and outputs a thresholded version
% according to its histogram. Threshold occurs in the first valley.
function [I_out2, TT] = valley_hist(I_out, HIST_LENGTH)
[N, X] = hist(I_out(:), HIST_LENGTH);
%Append the first signal to twice to the left of the histogram, and the
%last twice to the right of the histogram.
N_ext = [N(1) N(1) N N(HIST_LENGTH) N(HIST_LENGTH)];

N1 = N_ext(1:length(N)) - N;
N2 = N_ext(2:length(N)+1) - N;
N3 = N_ext(4:length(N)+3) - N;
N4 = N_ext(5:length(N)+4) - N;
%keyboard
%Put N1-N4 into a matrix
N_tot = [N1; N2; N3; N4];
N_tot(N_tot==0) = 1; 
N_tot(N_tot< 0) = 0; 
N_tot(N_tot~=0) = 1;

S = sum(N);
C = cumsum(N)/S;

f2 = find(C > 0.95);

%We define a valley as being a "V" shape in the histogram with at least two
%consecutive decreasing values followed by 2 consecutive increasing values,
%in order to prevent local minima that are not valley shaped.
SS = sum(N_tot);
SS(f2) = 0;
SS(1) = 0;
SS(length(N)) = 0;

fv = find(SS==4);
f_safe = fv;
for i=1:length(fv)
    if(N_tot(2,fv(i)-1) == 1)&&(N_tot(3,fv(i)+1) == 1) %enforcing the "V" shape
        
    else
        fv(i)=0;
    end
end

fv = fv(find(fv));

% Threshold at valley
I_out2 = I_out;
if(isempty(fv))
    display(sprintf('image: fv empty. Length= %i',HIST_LENGTH));
    %If no such V-shape exist, increase the number of bins of the histogram
    %and reprocess the image.
    if(HIST_LENGTH < 60) %beyond that it can get too noisy but the number shouldn't be reached.
        [I_out2 T] = valley_hist(I_out,round(HIST_LENGTH*1.1));
    else
        
    end
else
    length(fv)
    
%     if(length(fv)>2)
%         display(sprintf('image: fv V 2 ok. Length= %i', HIST_LENGTH));
%         TT = X(fv(2));
%     else
        display(sprintf('image: fv V 1 ok. Length= %i', HIST_LENGTH));
        TT = X(fv(1));
%         if(TT<0.12)
%             display('noise');
%             if(length(fv)>=2)
%                 TT = X(fv(2));
%             end
%             
%         end
%     end
    I_out2(I_out<TT) = 0;
    I_out2(I_out>=TT) = 1;
end
%}

%%%% CREATE FUNCTIONS
% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% --- Executes during object creation, after setting all properties.
function edit_theta_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function edit_a_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function edit_threshold_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox_useratios.
function checkbox_useratios_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_useratios (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_useratios
handles.useratios = get(hObject,'Value');

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in checkbox_smooth_result.
function checkbox_smooth_result_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_smooth_result (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_useratios
handles.smooth_result = get(hObject,'Value');

% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in checkbox_handle_sky.
function checkbox_handle_sky_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox_handle_sky (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox_handle_sky

% Hint: get(hObject,'Value') returns toggle state of checkbox_useratios
handles.handle_sky = get(hObject,'Value');

% Update handles structure
guidata(hObject, handles);



function edit_b_Callback(hObject, eventdata, handles)
% hObject    handle to edit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit_b as text
%        str2double(get(hObject,'String')) returns contents of edit_b as a double

handles.b = str2double(get(hObject,'String'));

xx = 0:0.01:1;
yy = 1.0 ./ (1 + exp(-handles.a .*(xx-handles.b)));
axes(handles.axes_sigmoid)
plot(xx, yy)
axis([0.0, 1.0, 0.0, 1.0]);

% Update handles structure
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit_b_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
